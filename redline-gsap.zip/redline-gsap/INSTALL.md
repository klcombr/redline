# REDLINE — packs GSAP + Three.js — instalação

**REDLINE** é a disciplina de criação de sites (anti-slop). Ela vem com os
**dois packs oficiais**: o **GSAP pack** (animação, 8 skills) e o **Three.js
pack** (3D, 10 skills). O brief do usuário decide qual usar — pediu animado,
anima com GSAP; pediu 3D, entrega Three.js de verdade; pediu seco, fica seco.

## O que está neste pacote (19 skills)

```
redline-gsap/
├── REDLINE-SKILL.md          # a disciplina (v1.2, nome: redline)
├── skills/
│   # GSAP — motion (8)
│   ├── gsap-core/            # tweens, easing, stagger, matchMedia
│   ├── gsap-timeline/        # sequências e coreografia
│   ├── gsap-scrolltrigger/   # scroll-linked, pin, scrub
│   ├── gsap-react/           # useGSAP, cleanup, refs
│   ├── gsap-frameworks/      # Vue, Svelte e outros
│   ├── gsap-plugins/         # Flip, SplitText, MorphSVG, Draggable…
│   ├── gsap-performance/     # 60fps, transform-only, sem layout thrash
│   ├── gsap-utils/           # clamp, mapRange, snap, wrap…
│   # Three.js — 3D (10)
│   ├── threejs-fundamentals/ # cena, câmera, renderer, hierarquia
│   ├── threejs-geometry/     # shapes, BufferGeometry, instancing
│   ├── threejs-materials/    # PBR, phong, shader materials
│   ├── threejs-textures/     # texturas, UV, environment maps
│   ├── threejs-lighting/     # luzes, sombras, IBL
│   ├── threejs-shaders/      # GLSL, ShaderMaterial, uniforms
│   ├── threejs-loaders/      # GLTF, texturas, HDR, progresso
│   ├── threejs-animation/    # keyframes, skeletal, morph targets
│   ├── threejs-interaction/  # raycasting, controls, input
│   └── threejs-postprocessing/ # EffectComposer, bloom, DOF
└── INSTALL.md                # este arquivo
```

Cada pasta contém um `SKILL.md` no formato Agent Skills, com frontmatter
`name` + `description`.

## Instalar em qualquer agente (Hermes, Claude, Cursor, etc.)

1. **REDLINE** → coloque `REDLINE-SKILL.md` onde o agente lê skills
   (normalmente numa pasta `skills/redline/`, renomeado para `SKILL.md`).
   Se o agente não tiver pasta de skills, cole o conteúdo inteiro no
   config/instructions.
2. **Packs** → copie cada pasta `skills/gsap-*` e `skills/threejs-*` para o
   mesmo diretório de skills (ex.: `skills/gsap-core/SKILL.md`).
3. **Registre no índice** de skills do agente, se existir (uma linha por
   skill). O nome em cada frontmatter deve bater com a pasta.
4. **Reinicie a sessão** — skills são descobertas na inicialização.

## Instalar no opencode

```sh
mkdir -p ~/.config/opencode/skills
cp REDLINE-SKILL.md ~/.config/opencode/skills/redline/SKILL.md
cp -r skills/gsap-* skills/threejs-* ~/.config/opencode/skills/
# índice (lazy-load): adicione uma linha por skill em
# ~/.local/share/opencode/skills-index.md
```

## Como o REDLINE escolhe o pack

O brief manda. A disciplina polida a execução — nunca sobrepõe o pedido:

- **Pediu 3D?** → Three.js de verdade (cena, luz, assets, interação, pós).
- **Pediu 2D?** → só 2D, sem WebGL gratuito.
- **Pediu seco?** → seco: sem entrances, sem parallax, direto ao ponto.
- **Pediu animado?** → tudo que pode carregar sentido anima: transições entre
  páginas HTML, reveals, parallax, marquee, scrubs — com o padrão de page
  transition descrito na "PART IV" da skill.

Detalhes na "PART IV — Motion & the packs" do `REDLINE-SKILL.md`.

Fatos verdadeiros (não inventados): GSAP é 100% gratuito incluindo todos os
plugins (npm `gsap`, React `@gsap/react`); Three.js é gratuito e open source
(npm `three`). Skills GSAP © GreenSock (MIT). Skills Three.js © autoria do
repositório (MIT).

v1.2.0 · MIT