---
name: animejs
description: Animation skill for Anime.js v4. Use when building or reviewing website animations with Anime.js, including DOM, CSS, SVG, JavaScript objects, timelines, staggering, playback control, and React/Vue integrations. Provides current v4 module imports, API patterns, accessibility, performance, and cleanup guidance. Respect a library explicitly chosen by the user; otherwise choose the simplest suitable animation tool.
---

# Anime.js v4

Use Anime.js when the user explicitly asks for Anime.js, or when its compact
animation engine is a good fit for DOM, CSS, SVG, and JavaScript-object motion.
This skill targets **Anime.js v4**; do not use v3 APIs such as `anime.timeline()`.

## When to use

- DOM elements, CSS properties, CSS transforms, CSS variables, attributes, and SVG.
- Small-to-medium interaction systems, reveals, counters, icon motion, and stagger effects.
- JavaScript object animation when the rendered value is controlled by code.
- A lightweight alternative when complex scroll orchestration is not required.

For long, complex, scroll-driven timelines, choose GSAP or Motion unless the
user specifically requests Anime.js. For React declarative UI animation,
Motion (`motion/react`) is often a better default. Always honor the user's
library choice.

## Install and import

```bash
npm install animejs
```

Use v4 ESM imports:

```javascript
import { animate, createTimeline, stagger, utils } from "animejs"
```

Useful entry points:

```javascript
import { animate } from "animejs"
import { createTimeline, stagger } from "animejs"
import { utils } from "animejs/utils"
```

Prefer named imports and tree-shakeable modules. Do not use the v3 global
`anime` API or `anime.timeline()` in new code.

## Animate elements

Targets may be a CSS selector, an element, an array/NodeList, or a JavaScript
object.

```javascript
import { animate } from "animejs"

const reveal = animate(".reveal", {
  opacity: [0, 1],
  translateY: [18, 0],
  duration: 600,
  delay: 80,
  ease: "outExpo",
  onComplete: () => reveal.revert(),
})
```

Prefer transform properties such as `translateX`, `translateY`, `scale`, and
`rotate` over animating `top`, `left`, `width`, or `height` when the visual
result does not require layout changes.

### Common parameters

- `duration`: duration in milliseconds.
- `delay`: delay before the animation starts.
- `ease`: named easing such as `outExpo`, `inOutQuad`, `out(3)`, or an easing function.
- `loop`: repeat count; use `true` only for intentional, rhythm-based motion.
- `alternate`: reverse direction on alternate loops.
- `reversed`: start in reverse.
- `autoplay`: set to `false` when the animation must be controlled manually.
- `onBegin`, `onUpdate`, `onComplete`: lifecycle callbacks.
- `onLoop`: callback for each loop.

Keep entrance animations short and interruptible. Never block the primary
interaction on a decorative entrance.

## Timelines and choreography

Use a timeline when several animations need a shared sequence or labels:

```javascript
import { createTimeline, stagger } from "animejs"

const tl = createTimeline({
  defaults: {
    duration: 650,
    ease: "outExpo",
  },
})

tl.add(".nav-item", {
  opacity: [0, 1],
  translateY: [-12, 0],
  delay: stagger(60),
})
  .add(".hero-title", {
    opacity: [0, 1],
    scale: [0.96, 1],
  }, "-=350")
  .add(".hero-copy", {
    opacity: [0, 1],
    translateY: [12, 0],
  }, "-=420")
```

Use labels or relative offsets (`-=`, `+=`) instead of a chain of guessed
millisecond delays. Keep the timeline reference so it can be paused,
reversed, or reverted when the component leaves.

## Stagger

Use `stagger()` for offsets between multiple targets or for staggered values:

```javascript
import { animate, stagger } from "animejs"

animate(".list-row", {
  opacity: [0, 1],
  translateX: [-12, 0],
  delay: stagger(50, { from: "first" }),
})

animate(".meter", {
  scaleY: stagger([0.2, 1, 0.6]),
  alternate: true,
})
```

For a list that can be long or is rendered dynamically, cap the total delay
or calculate it from the visible viewport. A stagger must not make the last
item feel late or unusable.

## Playback control and cleanup

Anime.js animations expose playback methods such as `play`, `pause`,
`restart`, `reverse`, `seek`, `complete`, `reset`, `cancel`, and `revert`.
Store the returned animation or timeline when interaction controls or cleanup
are needed.

```javascript
const panel = animate(".panel", {
  translateX: [40, 0],
  opacity: [0, 1],
  autoplay: false,
})

document.querySelector("#open-panel")?.addEventListener("click", () => {
  panel.restart()
})

// When the owner is removed:
panel.pause()
panel.revert()
```

- `cancel()` stops playback without necessarily restoring the initial state.
- `revert()` removes Anime.js-applied values and restores the original state;
  use it for component unmount or a complete visual reset.
- Remove event listeners created for the animation when the owner is removed.
- Do not create an animation loop for work that CSS can do more cheaply.

## React and component lifecycles

Run DOM animation in `useEffect` or another client-only effect. Guard SSR and
return cleanup from the effect:

```jsx
import { useEffect, useRef } from "react"
import { animate } from "animejs"

export function Reveal({ children }) {
  const ref = useRef(null)

  useEffect(() => {
    const animation = animate(ref.current, {
      opacity: [0, 1],
      translateY: [16, 0],
      duration: 500,
      ease: "outExpo",
    })

    return () => {
      animation.pause()
      animation.revert()
    }
  }, [])

  return <div ref={ref}>{children}</div>
}
```

For React Strict Mode, ensure effects are idempotent and cleanup is complete.
For Vue, put setup in `onMounted` and call `pause()`/`revert()` in
`onBeforeUnmount`.

## Performance and accessibility

- Prefer `transform` and `opacity` for frequent motion.
- Avoid animating many DOM properties in a large scroll loop.
- Use `will-change` sparingly and remove it when the animation is no longer
  needed.
- Respect `prefers-reduced-motion`; provide a static or near-instant state.
- Do not hide focusable controls behind an entrance animation.
- Do not use constant floating, bouncing, or looping motion by default.
- Verify the page remains usable when JavaScript is unavailable or an asset
  fails to load.

Check reduced motion before writing the animation:

```javascript
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)")

animate(".reveal", {
  opacity: 1,
  translateY: 0,
  duration: reduceMotion.matches ? 0 : 500,
})
```

## Verification checklist

1. Confirm the installed package is Anime.js v4.
2. Confirm every target exists and is present at the time the animation starts.
3. Verify play, pause, reverse, cancel, and revert behavior where controls exist.
4. Verify cleanup on route changes, component unmount, and repeated mounts.
5. Verify keyboard focus, touch input, reduced motion, and no-WebGL/no-JS
   fallbacks when the page depends on them.
6. Inspect the browser console and performance profile for jank or overlapping
   animations.

## Official references

- https://animejs.com/documentation/
- https://animejs.com/documentation/getting-started/installation
- https://animejs.com/documentation/animation
- https://animejs.com/documentation/timer
- https://animejs.com/documentation/utilities
